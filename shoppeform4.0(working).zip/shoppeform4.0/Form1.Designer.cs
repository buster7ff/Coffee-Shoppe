﻿namespace shoppeform4._0
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pop = new System.Windows.Forms.Label();
            this.addPop = new System.Windows.Forms.Button();
            this.Total = new System.Windows.Forms.TextBox();
            this.lbxMoneyList = new System.Windows.Forms.ListBox();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // pop
            // 
            this.pop.AutoSize = true;
            this.pop.Location = new System.Drawing.Point(31, 158);
            this.pop.Name = "pop";
            this.pop.Size = new System.Drawing.Size(25, 13);
            this.pop.TabIndex = 0;
            this.pop.Text = "pop";
            this.pop.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.pop.Click += new System.EventHandler(this.pop_Click);
            // 
            // addPop
            // 
            this.addPop.Location = new System.Drawing.Point(143, 34);
            this.addPop.Name = "addPop";
            this.addPop.Size = new System.Drawing.Size(75, 74);
            this.addPop.TabIndex = 1;
            this.addPop.Text = "addPop";
            this.addPop.UseVisualStyleBackColor = true;
            this.addPop.Click += new System.EventHandler(this.addPop_Click);
            // 
            // Total
            // 
            this.Total.Location = new System.Drawing.Point(228, 197);
            this.Total.Name = "Total";
            this.Total.Size = new System.Drawing.Size(100, 20);
            this.Total.TabIndex = 2;
            this.Total.TextChanged += new System.EventHandler(this.Total_TextChanged);
            // 
            // lbxMoneyList
            // 
            this.lbxMoneyList.FormattingEnabled = true;
            this.lbxMoneyList.Location = new System.Drawing.Point(427, 122);
            this.lbxMoneyList.Name = "lbxMoneyList";
            this.lbxMoneyList.Size = new System.Drawing.Size(120, 95);
            this.lbxMoneyList.TabIndex = 3;
            this.lbxMoneyList.SelectedIndexChanged += new System.EventHandler(this.lbxMoneyList_SelectedIndexChanged);
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(427, 12);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(120, 95);
            this.listBox1.TabIndex = 4;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(559, 261);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.lbxMoneyList);
            this.Controls.Add(this.Total);
            this.Controls.Add(this.addPop);
            this.Controls.Add(this.pop);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label pop;
        private System.Windows.Forms.Button addPop;
        private System.Windows.Forms.TextBox Total;
        private System.Windows.Forms.ListBox lbxMoneyList;
        private System.Windows.Forms.ListBox listBox1;
    }
}

