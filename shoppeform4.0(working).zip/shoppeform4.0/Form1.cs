﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MoneyLib;

namespace shoppeform4._0
{
    public partial class Form1 : Form
    {
        Coke c;
        Sprite s;
       
        public Form1()
        {
            InitializeComponent();
            listBox1.Items.Add(new Coke());
            listBox1.Items.Add(new Sprite());

        }
       
        private void pop_Click(object sender, EventArgs e)
        {

        }

        private void addPop_Click(object sender, EventArgs e)
        {

            lbxMoneyList.Items.Add(listBox1.SelectedItem);
            GetSelectedTotal();
        
 
          

        }

        private void GetSelectedTotal()
        {
            decimal tempValue = 0.0m;
            foreach (Pop p in lbxMoneyList.Items)
            {
                tempValue += p.Price.Value;
            }
            Total.Text = tempValue.ToString();
        }

        private void Total_TextChanged(object sender, EventArgs e)
        {

        }

        private void lbxMoneyList_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
