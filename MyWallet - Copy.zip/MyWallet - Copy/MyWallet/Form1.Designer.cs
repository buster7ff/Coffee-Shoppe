﻿namespace MyWallet
{
    partial class Wallet
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.RemoveBtn = new System.Windows.Forms.Button();
            this.AddRemoveQuarter = new System.Windows.Forms.NumericUpDown();
            this.AddRemoveDime = new System.Windows.Forms.NumericUpDown();
            this.AddRemoveNickel = new System.Windows.Forms.NumericUpDown();
            this.AddRemovePenny = new System.Windows.Forms.NumericUpDown();
            this.QuarterLabel = new System.Windows.Forms.Label();
            this.DimeLabel = new System.Windows.Forms.Label();
            this.NickelLabel = new System.Windows.Forms.Label();
            this.PennyLabel = new System.Windows.Forms.Label();
            this.AddBtn = new System.Windows.Forms.Button();
            this.lbxMoneylist = new System.Windows.Forms.ListBox();
            this.WalletAmount = new System.Windows.Forms.TextBox();
            this.WalletLabel = new System.Windows.Forms.Label();
            this.ExitBtn = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.AddRemoveQuarter)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.AddRemoveDime)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.AddRemoveNickel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.AddRemovePenny)).BeginInit();
            this.SuspendLayout();
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.RemoveBtn);
            this.splitContainer1.Panel1.Controls.Add(this.AddRemoveQuarter);
            this.splitContainer1.Panel1.Controls.Add(this.AddRemoveDime);
            this.splitContainer1.Panel1.Controls.Add(this.AddRemoveNickel);
            this.splitContainer1.Panel1.Controls.Add(this.AddRemovePenny);
            this.splitContainer1.Panel1.Controls.Add(this.QuarterLabel);
            this.splitContainer1.Panel1.Controls.Add(this.DimeLabel);
            this.splitContainer1.Panel1.Controls.Add(this.NickelLabel);
            this.splitContainer1.Panel1.Controls.Add(this.PennyLabel);
            this.splitContainer1.Panel1.Controls.Add(this.AddBtn);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.WalletAmount);
            this.splitContainer1.Panel2.Controls.Add(this.WalletLabel);
            this.splitContainer1.Panel2.Controls.Add(this.ExitBtn);
            this.splitContainer1.Panel2.Controls.Add(this.lbxMoneylist);
            this.splitContainer1.Size = new System.Drawing.Size(284, 261);
            this.splitContainer1.SplitterDistance = 132;
            this.splitContainer1.TabIndex = 0;
            // 
            // RemoveBtn
            // 
            this.RemoveBtn.Location = new System.Drawing.Point(67, 212);
            this.RemoveBtn.Name = "RemoveBtn";
            this.RemoveBtn.Size = new System.Drawing.Size(62, 37);
            this.RemoveBtn.TabIndex = 9;
            this.RemoveBtn.Text = "&Remove";
            this.RemoveBtn.UseVisualStyleBackColor = true;
            this.RemoveBtn.Click += new System.EventHandler(this.RemoveBtn_Click);
            // 
            // AddRemoveQuarter
            // 
            this.AddRemoveQuarter.ForeColor = System.Drawing.Color.DarkGreen;
            this.AddRemoveQuarter.Location = new System.Drawing.Point(44, 115);
            this.AddRemoveQuarter.Name = "AddRemoveQuarter";
            this.AddRemoveQuarter.Size = new System.Drawing.Size(85, 20);
            this.AddRemoveQuarter.TabIndex = 8;
            this.AddRemoveQuarter.ValueChanged += new System.EventHandler(this.AddRemoveQuarter_ValueChanged);
            // 
            // AddRemoveDime
            // 
            this.AddRemoveDime.ForeColor = System.Drawing.Color.Firebrick;
            this.AddRemoveDime.Location = new System.Drawing.Point(44, 82);
            this.AddRemoveDime.Name = "AddRemoveDime";
            this.AddRemoveDime.Size = new System.Drawing.Size(85, 20);
            this.AddRemoveDime.TabIndex = 7;
            this.AddRemoveDime.ValueChanged += new System.EventHandler(this.AddRemoveDime_ValueChanged);
            // 
            // AddRemoveNickel
            // 
            this.AddRemoveNickel.ForeColor = System.Drawing.Color.Red;
            this.AddRemoveNickel.Location = new System.Drawing.Point(44, 48);
            this.AddRemoveNickel.Name = "AddRemoveNickel";
            this.AddRemoveNickel.Size = new System.Drawing.Size(85, 20);
            this.AddRemoveNickel.TabIndex = 6;
            this.AddRemoveNickel.ValueChanged += new System.EventHandler(this.AddRemoveNickel_ValueChanged);
            // 
            // AddRemovePenny
            // 
            this.AddRemovePenny.ForeColor = System.Drawing.Color.Tomato;
            this.AddRemovePenny.Location = new System.Drawing.Point(44, 18);
            this.AddRemovePenny.Name = "AddRemovePenny";
            this.AddRemovePenny.Size = new System.Drawing.Size(85, 20);
            this.AddRemovePenny.TabIndex = 5;
            this.AddRemovePenny.ValueChanged += new System.EventHandler(this.AddRemovePenny_ValueChanged);
            // 
            // QuarterLabel
            // 
            this.QuarterLabel.AutoSize = true;
            this.QuarterLabel.Location = new System.Drawing.Point(3, 117);
            this.QuarterLabel.Name = "QuarterLabel";
            this.QuarterLabel.Size = new System.Drawing.Size(42, 13);
            this.QuarterLabel.TabIndex = 4;
            this.QuarterLabel.Text = "Quarter";
            this.QuarterLabel.Click += new System.EventHandler(this.QuarterLabel_Click);
            // 
            // DimeLabel
            // 
            this.DimeLabel.AutoSize = true;
            this.DimeLabel.Location = new System.Drawing.Point(3, 84);
            this.DimeLabel.Name = "DimeLabel";
            this.DimeLabel.Size = new System.Drawing.Size(31, 13);
            this.DimeLabel.TabIndex = 3;
            this.DimeLabel.Text = "Dime";
            this.DimeLabel.Click += new System.EventHandler(this.DimeLabel_Click);
            // 
            // NickelLabel
            // 
            this.NickelLabel.AutoSize = true;
            this.NickelLabel.Location = new System.Drawing.Point(3, 50);
            this.NickelLabel.Name = "NickelLabel";
            this.NickelLabel.Size = new System.Drawing.Size(37, 13);
            this.NickelLabel.TabIndex = 2;
            this.NickelLabel.Text = "Nickel";
            this.NickelLabel.Click += new System.EventHandler(this.NickelLabel_Click);
            // 
            // PennyLabel
            // 
            this.PennyLabel.AutoSize = true;
            this.PennyLabel.Location = new System.Drawing.Point(3, 20);
            this.PennyLabel.Name = "PennyLabel";
            this.PennyLabel.Size = new System.Drawing.Size(37, 13);
            this.PennyLabel.TabIndex = 1;
            this.PennyLabel.Text = "Penny";
            this.PennyLabel.Click += new System.EventHandler(this.PennyLabel_Click);
            // 
            // AddBtn
            // 
            this.AddBtn.Location = new System.Drawing.Point(3, 212);
            this.AddBtn.Name = "AddBtn";
            this.AddBtn.Size = new System.Drawing.Size(58, 37);
            this.AddBtn.TabIndex = 0;
            this.AddBtn.Text = "&Add";
            this.AddBtn.UseVisualStyleBackColor = true;
            this.AddBtn.Click += new System.EventHandler(this.AddBtn_Click);
            // 
            // lbxMoneylist
            // 
            this.lbxMoneylist.FormattingEnabled = true;
            this.lbxMoneylist.Location = new System.Drawing.Point(10, 96);
            this.lbxMoneylist.Name = "lbxMoneylist";
            this.lbxMoneylist.Size = new System.Drawing.Size(120, 95);
            this.lbxMoneylist.TabIndex = 7;
            // 
            // WalletAmount
            // 
            this.WalletAmount.Location = new System.Drawing.Point(45, 22);
            this.WalletAmount.Name = "WalletAmount";
            this.WalletAmount.ReadOnly = true;
            this.WalletAmount.Size = new System.Drawing.Size(100, 20);
            this.WalletAmount.TabIndex = 6;
            this.WalletAmount.TextChanged += new System.EventHandler(this.WalletAmount_TextChanged);
            // 
            // WalletLabel
            // 
            this.WalletLabel.AutoSize = true;
            this.WalletLabel.Location = new System.Drawing.Point(7, 25);
            this.WalletLabel.Name = "WalletLabel";
            this.WalletLabel.Size = new System.Drawing.Size(37, 13);
            this.WalletLabel.TabIndex = 5;
            this.WalletLabel.Text = "Wallet";
            // 
            // ExitBtn
            // 
            this.ExitBtn.Location = new System.Drawing.Point(10, 212);
            this.ExitBtn.Name = "ExitBtn";
            this.ExitBtn.Size = new System.Drawing.Size(126, 37);
            this.ExitBtn.TabIndex = 1;
            this.ExitBtn.Text = "&Exit";
            this.ExitBtn.UseVisualStyleBackColor = true;
            this.ExitBtn.Click += new System.EventHandler(this.ExitBtn_Click);
            // 
            // Wallet
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 261);
            this.Controls.Add(this.splitContainer1);
            this.Name = "Wallet";
            this.Text = "Wallet";
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel1.PerformLayout();
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.AddRemoveQuarter)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.AddRemoveDime)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.AddRemoveNickel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.AddRemovePenny)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.Button RemoveBtn;
        private System.Windows.Forms.NumericUpDown AddRemoveQuarter;
        private System.Windows.Forms.NumericUpDown AddRemoveDime;
        private System.Windows.Forms.NumericUpDown AddRemoveNickel;
        private System.Windows.Forms.NumericUpDown AddRemovePenny;
        private System.Windows.Forms.Label QuarterLabel;
        private System.Windows.Forms.Label DimeLabel;
        private System.Windows.Forms.Label NickelLabel;
        private System.Windows.Forms.Label PennyLabel;
        private System.Windows.Forms.Button AddBtn;
        private System.Windows.Forms.TextBox WalletAmount;
        private System.Windows.Forms.Label WalletLabel;
        private System.Windows.Forms.Button ExitBtn;
        private System.Windows.Forms.ListBox lbxMoneylist;
    }
}

