﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MoneyLib;
using MyWallet;


namespace MyWallet
{
    public partial class Wallet : Form
    {
        public Wallet()
        {
            InitializeComponent();
        }
        static Wallet wallet = new Wallet();
        static Currency testCurrency = new Currency("USD");
        static Penny p = new Penny();
        static Nickel n = new Nickel();
        static Dime d = new Dime();
        static Quarter q = new Quarter();
       



        public void PennyLabel_Click(object sender, EventArgs e)
        {
           
        }

        public void NickelLabel_Click(object sender, EventArgs e)
        {

        }

        public void DimeLabel_Click(object sender, EventArgs e)
        {

        }

        public void QuarterLabel_Click(object sender, EventArgs e)
        {

        }

        public void AddRemovePenny_ValueChanged(object sender, EventArgs e)
        {
           

        }

        public void AddRemoveNickel_ValueChanged(object sender, EventArgs e)
        {
            

        }

        private void AddRemoveDime_ValueChanged(object sender, EventArgs e)
        {
            

        }

        private void AddRemoveQuarter_ValueChanged(object sender, EventArgs e)
        {
            

        }

        public void AddBtn_Click(object sender, EventArgs e)
        {
            int tempCount = 0;
            tempCount = (int)AddRemovePenny.Value;
            for (int i = 0; i < tempCount; i++)
            {  
                lbxMoneylist.Items.Add(p);

            }
            tempCount = (int)AddRemoveNickel.Value;
            for (int i = 0; i < tempCount; i++)
            {
                lbxMoneylist.Items.Add(n);

            }

            tempCount = (int)AddRemoveDime.Value;
            for (int i = 0; i < tempCount; i++)
            {
                lbxMoneylist.Items.Add(d);

            }
            tempCount = (int)AddRemoveQuarter.Value;
            for (int i = 0; i < tempCount; i++)
            {
                lbxMoneylist.Items.Add(q);

            }
            AddRemovePenny.Value = 0;
            AddRemoveNickel.Value = 0;
            AddRemoveDime.Value = 0;
            AddRemoveQuarter.Value = 0;

            displayTotal();

        }

        private void displayTotal()
        {
            decimal temptotal = 0m;
            foreach (CirculatingMoney mn in lbxMoneylist.Items) {
                temptotal += mn.Value;

            }
            WalletAmount.Text = temptotal.ToString();
        }
              

        private void RemoveBtn_Click(object sender, EventArgs e)
        {
          
            lbxMoneylist.Items.Clear();
            WalletAmount.Clear();

        }

        private void WalletAmount_TextChanged(object sender, EventArgs e)
        {

            
            

        }

    
        private void ExitBtn_Click(object sender, EventArgs e)
        {
            this.Close();

        }
    }
}
