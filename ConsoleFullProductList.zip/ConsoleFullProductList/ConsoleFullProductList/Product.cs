﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MoneyLib;
namespace ConsoleFullProductList
{
    public class Product
    {
        public Money Price;
        public string Name;
        public int Volume;

        public Product(string newTitle, int newVolume, Money newAmount)
        {
            Name = newTitle;
            Volume = newVolume;
            Price = newAmount;
        }

    }

    public class Pop : Product
    {
        public Pop() : base("Pop", 12, new Money(new Currency("USD"),1.95m))
        {

        }
    }

    public class Chips : Product

    {
        public Chips() : base("Chips", 16, new Money(new Currency("USD"), 2.25m))
        {

        }
    }

    public class Sandwich : Product
    {
        public Sandwich() : base("Sandwich", 6, new Money(new Currency("USD"), 6.99m))
        {

        }
    }

    public class Coffee : Product
    {
        public Coffee() : base("Coffee", 20, new Money(new Currency("USD"), 3.29m))
        {
        
        }
    }



}
