﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MoneyLib;

namespace ConsoleFullProductList
{
    class Program
    {
        static void Main(string[] args)
        {
            Pop p;
            Chips c;
            Sandwich s;
            Coffee f;
            p = new Pop();
            c = new Chips();
            s = new Sandwich();
            f = new Coffee();
            Console.WriteLine("A {0} costs {1}", p.Name, p.Price.Value);
            Console.WriteLine("And {0} cost {1}", c.Name, c.Price.Value);
            Console.WriteLine("A {0} costs {1}", s.Name, s.Price.Value);
            Console.WriteLine("A {0} is {1}", f.Name, f.Price.Value);
            Console.WriteLine("Total Cost: {0}", p.Price.Value + c.Price.Value + s.Price.Value + f.Price.Value);
            Console.ReadLine();

        }
    }
}
